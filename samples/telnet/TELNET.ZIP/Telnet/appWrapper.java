/**
 * appWrapper -- applet/application wrapper
 * --
 * $Id: appWrapper.java,v 1.3 1997/02/18 14:19:10 leo Exp $
 * $timestamp: Tue Feb 18 15:18:46 1997 by Matthias L. Jugel :$
 *
 * This file is part of "The Java Telnet Applet".
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * "The Java Telnet Applet" is distributed in the hope that it will be 
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

import java.applet.Applet;
import java.applet.AppletStub;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.FontMetrics;

/**
 * The appWrapper is thought to make the applet itself independent from
 * the original context. This is necessary to be able to detach the applet
 * from the web browsers window without disconnecting it from events.
 * Note: This applet should work with any applet without changes.
 *
 * @version $Id: appWrapper.java,v 1.3 1997/02/18 14:19:10 leo Exp $
 * @author  Matthias L. Jugel
 */
public class appWrapper extends Applet implements AppletStub
{
  Applet applet = null;
  
  /**
   * Applet initialization. We load the class giving in parameter "app"
   * and set the stub corresponding to ours. Thus we are able to give
   * it access to the parameters and any applet specific context.
   */
  public void init()
  {
    if(getParameter("applet") == null) {
      showStatus("appWrapper: missing applet parameter, nothing loaded");
      System.err.println("appWrapper: missing applet parameter");
      return;
    }
    
    if(applet == null) try {
      applet = (Applet)Class.forName(getParameter("applet")).newInstance();
      applet.setStub(this);
    } catch(Exception e) {
      System.err.println("appWrapper: could not load "+getParameter("applet"));
      e.printStackTrace();
    }
    applet.init();
    setLayout(new BorderLayout());
    add("Center", applet);
  }
  
  /**
   * After initializing the applet it will be started.
   */
  public void start()
  {
    if(applet == null)
      System.err.println("appWrapper: unable to start applet");
    else applet.start();
  }

  /**
   * This method is called when the applet want's to be resized.
   * @param width the width of the applet
   * @param height the height of the applet
   */
  public void appletResize(int width, int height) {
    System.err.println("appWrapper: appletResize()");
    if(applet != null) applet.resize(width, height);
  }
  
  /**
   * Give information about the appWrapper and the applet loaded.
   */
  public String[][] getParameterInfo()
  {
    String info[][];
    String wrapper[][] = {
      {"applet",   "String",   "appWrapper: Applet to load"},
    };
    if(applet != null) {
      String tmp[][] = applet.getParameterInfo();
      info = new String[tmp.length + 1][3];
      System.arraycopy(tmp, 0, info, 1, tmp.length);
    }
    else info = new String[1][3];
    System.arraycopy(wrapper, 0, info, 0, 1);
      
    return info;
  }

  /**
   * Write a message to the applet area.
   */
  public void paint(Graphics g) 
  {
    String message;
    if(applet != null) message = "The applet has been detached!";
    else message = "The was no applet load (maybe an error)!";

    
    int width = size().width / 2 - 
      (getFontMetrics(getFont())).stringWidth(message) / 2;
    int height = size().height / 2;
    
    g.setColor(Color.red);
    g.drawString(message, width, height);
  }
  
  /**
   * reshape the applet and ourself
   */
  public void reshape(int x, int y, int w, int h)
  {
    if(applet != null) applet.reshape(x, y, w, h);
    super.reshape(x, y, w, h);
  }
  
}
