/*
 * vt320 -- a DEC VT320 Terminal emulation
 * --
 * $Id: vt320.java,v 1.15 1997/02/16 15:53:00 leo Exp leo $
 * $timestamp: Thu Feb 20 09:45:45 1997 by Matthias L. Jugel :$
 *
 * This file is part of "The Java Telnet Applet".
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * "The Java Telnet Applet" is distributed in the hope that it will be 
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

package display;

import display.Terminal;

import java.awt.Scrollbar;
import java.awt.Event;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.Vector;

import java.applet.Applet;

/**
 * A DEC VT320 Terminal is an emulation class.
 *
 * @version $Id: vt320.java,v 1.15 1997/02/16 15:53:00 leo Exp leo $
 * @author  Matthias L. Jugel, Marcus Mei�ner
 */
public class vt320 extends Terminal
{
  	/* Scrollbar */
        private Scrollbar sb;
  
	/* The character display */
  	private CharDisplay display;
	private static int debug = 0;
  	private String terminalID = "vt320";
  
	/* X - COLUMNS, Y - ROWS */
	int	R,C;
	int	Sc,Sr,Sa;
	int	attributes	= 0;
	int	insertmode	= 0;
	int	vt52mode	= 0;
	int	normalcursor	= 0;

	private	static	int	lastwaslf = 0;
	private static	int i;
	private final static char ESC = 27;
	private final static char CSI = 233;
	private final static char IND = 132;
	private final static char NEL = 133;
	private final static char HTS = 136;
	private final static char DCS = 144;
	private final static char OSC = 157;
	private final static int TSTATE_DATA	= 0;
	private final static int TSTATE_ESC	= 1; /* ESC */
	private final static int TSTATE_CSI	= 2; /* ESC [ */
	private final static int TSTATE_DCS	= 3; /* ESC P */
	private final static int TSTATE_DCEQ	= 4; /* ESC [? */
	private final static int TSTATE_ESCSQUARE= 5; /* ESC # */
	private final static int TSTATE_OSC= 6;       /* ESC ] */
	private final static int TSTATE_SETG0= 7;     /* ESC (? */
	private final static int TSTATE_SETG1= 8;     /* ESC )? */
	private final static int TSTATE_SETG2= 9;     /* ESC *? */
	private final static int TSTATE_SETG3= 10;    /* ESC +? */

	/* Font set designations  (need to add 96 char support later) */
	/* 0 - DEC special char & line draw */
	/* A - United Kingdom (UK) */
	/* B - United States (USASCII) */
	private static char g0 = 'B';	// default ASCII as G0
	private static char g1 = '0';	// default DEC as G1
	private static char g2 = 'A';	// default UK as G2
	private static char g3 = '<';	// default User Def in G3
	private static char gr = '0';	// default GR to DEC
	private static char gl = 'B';	// default GL (main font) to ASCII
	// array to store DEC Special -> Unicode mapping
	//  Unicode   DEC  Unicode name    (DEC name)
	private static char DECSPECIAL[] = {
	    '\u0040', //5f blank
	    '\u2666', //60 black diamond
	    '\u2592', //61 grey square
	    '\u2409', //62 Horizontal tab  (ht) pict. for control
	    '\u240c', //63 Form Feed       (ff) pict. for control
	    '\u240d', //64 Carriage Return (cr) pict. for control
	    '\u240a', //65 Line Feed       (lf) pict. for control
	    '\u00ba', //66 Masculine ordinal indicator
	    '\u00b1', //67 Plus or minus sign
	    '\u2424', //68 New Line        (nl) pict. for control
	    '\u240b', //69 Vertical Tab    (vt) pict. for control
 	    '\u2518', //6a Forms light up   and left
	    '\u2510', //6b Forms light down and left
	    '\u250c', //6c Forms light down and right
	    '\u2514', //6d Forms light up   and right
	    '\u253c', //6e Forms light vertical and horizontal
	    '\u2594', //6f Upper 1/8 block                        (Scan 1)
	    '\u2580', //70 Upper 1/2 block                        (Scan 3)
	    '\u2500', //71 Forms light horizontal or ?em dash?    (Scan 5)
	    '\u25ac', //72 \u25ac black rect. or \u2582 lower 1/4 (Scan 7)
	    '\u005f', //73 \u005f underscore  or \u2581 lower 1/8 (Scan 9)
	    '\u251c', //74 Forms light vertical and right
	    '\u2524', //75 Forms light vertical and left
	    '\u2534', //76 Forms light up   and horizontal
	    '\u252c', //77 Forms light down and horizontal
	    '\u2502', //78 vertical bar
	    '\u2264', //79 less than or equal
	    '\u2265', //7a greater than or equal
	    '\u00b6', //7b paragraph
	    '\u2260', //7c not equal
	    '\u00a3', //7d Pound Sign (british)
	    '\u00b7'};//7e Middle Dot
	    

	private final static int KEYUP	= Event.UP % 1000;
	private final static int KEYDOWN= Event.DOWN % 1000;
	private final static int KEYLEFT= Event.LEFT % 1000;
	private final static int KEYRIGHT= Event.RIGHT % 1000;
	private final static int KEYF1	= Event.F1 % 1000;
	private final static int KEYF2	= Event.F2 % 1000;
	private final static int KEYF3	= Event.F3 % 1000;
	private final static int KEYF4	= Event.F4 % 1000;
	private final static int KEYPGDN = Event.PGDN % 1000;
	private final static int KEYPGUP = Event.PGUP % 1000;

	/** 
	 * Strings to send on function key presseic
	 */
	private String FunctionKey[];
	private String KeyUp;
	private String KeyDown;
	private String KeyLeft;
	private String KeyRight;

	private String osc,dcs;	/* to memorize OSC & DCS control sequence */

	private int term_state = TSTATE_DATA;
	private byte[]	Tabs;
	private int[]	DCEvars = new int [10];
	private	int	DCEvar;

        /* operation system we run on, Scrollbar hack */
        private String osn = System.getProperty("os.name");

	public String[][] getParameterInfo() {
	  String pinfo[][] = {
	    {"VTcolumns",  "Integer",   "Columns of the terminal"},
	    {"VTrows",     "Integer",   "Rows of the terminal"},
	    {"VTfont",     "String",    "Terminal font (default is Courier)"},
	    {"VTfontsize", "Integer",   "Font size"},
	    {"VTbuffer",   "Integer",   "Scrollback buffer size"},
	    {"VTscrollbar","Boolean",   "Enable or disable scrollbar"},
	    {"VTresize",   "String",    "One of none, font, screen"},
	    {"VTid",       "String",    "Terminal id, standard is VT320"},
	  };
	  return pinfo;
	}

	/**
	 * Initialize terminal.
	 * @param parent the applet parent where to get parameters from
	 * @see display.Terminal
	 */
	public void InitializeTerminal(Object parent){
	  String width = "80", height = "24", resize ="font";
	  String font = "Courier", fs = "14", bufs = "100";
	  String scrb = "false";
	  
	  if(parent != null) {
	    width = ((Applet)parent).getParameter("VTcolumns");
	    height = ((Applet)parent).getParameter("VTrows");
	    font = ((Applet)parent).getParameter("VTfont");
	    fs = ((Applet)parent).getParameter("VTfontsize");
	    bufs = ((Applet)parent).getParameter("VTbuffer");
	    scrb = ((Applet)parent).getParameter("VTscrollbar");
	    resize = ((Applet)parent).getParameter("VTresize");
	    resize = resize == null ? "font" : resize;
	    if(((Applet)parent).getParameter("VTid") != null)
	      terminalID = ((Applet)parent).getParameter("VTid");
	  }
	  display = new CharDisplay(width==null?80:(new Integer(width)).intValue(),
				    height==null?24:(new Integer(height)).intValue(),
				    font==null?"Courier":font,
				    fs==null?14:(new Integer(fs)).intValue());
	  display.setBufferSize(bufs==null?100:(new Integer(bufs)).intValue());
	  if(resize.equals("none")) 
	    display.setResizeStrategy(CharDisplay.RESIZE_NONE);
	  if(resize.equals("font")) 
	    display.setResizeStrategy(CharDisplay.RESIZE_FONT);
	  if(resize.equals("screen")) 
	    display.setResizeStrategy(CharDisplay.RESIZE_SCREEN);

	  setLayout(new BorderLayout());
	  if(scrb != null && !scrb.equals("false")) {
	    sb = new Scrollbar(Scrollbar.VERTICAL);
	    if(osn.equals("Windows 95"))
	      sb.setValues(display.getBufferSize() - display.getRows(), 
			   display.getRows(), 
			   0, 
			   display.getBufferSize());
	    else
	      sb.setValues(display.getBufferSize(), 
			   display.getRows(), 
			   0, 
			   display.getBufferSize() - display.getRows());
	    if(scrb.equals("left") || scrb.equals("true"))
	      add("West", sb);
	    else if(scrb.equals("right")) 
	      add("East", sb);
	    else
	      System.out.println("InitializeTerminal(): unknown scrollbar "
				 +"location: "+scrb);
	  }
	  add("Center", display);
	  InitTerminalVars();
  	}

	public void InitTerminalVars() {
	  int nw = display.getColumns();
	  Tabs = new byte[nw];
	  for (int i=0;i<nw;i+=8) {
	  	Tabs[i]=1;
	  }
	  FunctionKey = new String[20];
	  FunctionKey[0]= "";
	  FunctionKey[1]= "OP";
	  FunctionKey[2]= "OQ";
	  FunctionKey[3]= "OR";
	  FunctionKey[4]= "OS";
	  FunctionKey[5]= "";
	  FunctionKey[6]= "";
	  FunctionKey[7]= "";
	  FunctionKey[8]= "";
	  FunctionKey[9]= "";
	  FunctionKey[10]= "";
	  FunctionKey[11]= "";
	  FunctionKey[12]= "";
	  FunctionKey[13]= "";
	  FunctionKey[14]= "";
	  FunctionKey[15]= "";
	  FunctionKey[16]= "";
	  FunctionKey[17]= "";
	  FunctionKey[18]= "";
	  FunctionKey[19]= "";
	  KeyUp		= "[A";
	  KeyDown	= "[B";
	  KeyRight	= "[C";
	  KeyLeft	= "[D";
	}

  	public Dimension getSize() {
	  	return new Dimension(display.getColumns(), display.getRows());
	}

	public String getTerminalType() { return terminalID; }

	/**
	 * Handle events for the terminal. Only accept events for the scroll
	 * bar. Any other events have to be propagated to the parent.
	 * @param evt the event
	 */
  	public boolean handleEvent(Event evt) {
		String	tosend;
		Vector	vec;
		byte	msg[];

    		if(evt != null && evt.target == sb && evt.arg != null) {
			int val = ((Integer)evt.arg).intValue();
			if(val > display.getBufferSize() - display.getRows())
			  val = display.getBufferSize() - display.getRows();
      			display.setWindowBase(val);
      			return true;
    		}
		if(evt.id == Event.MOUSE_ENTER)
		{
		  requestFocus();
		  return true;
		}
		if(evt.id == Event.MOUSE_EXIT)
		{
		  nextFocus();
		  return true;
		}
		if (evt.id == evt.KEY_ACTION) {
			tosend = "";
			/* bloodsucking little buggers at netscape 
			 * don't keep to the standard java values
			 * of <ARROW> or <Fx> 
			 */
			switch (evt.key % 1000) {
			case KEYF1:
				tosend = FunctionKey[1];
				break;
			case KEYF2:
				tosend = FunctionKey[2];
				break;
			case KEYF3:
				tosend = FunctionKey[3];
				break;
			case KEYF4:
				tosend = FunctionKey[4];
				break;
			case KEYUP:
				tosend = KeyUp;
				break;
			case KEYDOWN:
				tosend = KeyDown;
				break;
			case KEYLEFT:
				tosend = KeyLeft;
				break;
			case KEYRIGHT:
				tosend = KeyRight;
				break;
			case KEYPGDN:
				tosend = "[6~";
				break;
			case KEYPGUP:
				tosend = "[5~";
				break;
			default:
				if (debug>0)
					System.out.println("unknown event:"+(int)evt.key);
				break;
			}

			msg = new byte[tosend.length()];
			tosend.getBytes(0, tosend.length(), msg, 0);
			vec = new Vector(2);
			vec.addElement("SEND");
			vec.addElement(msg);
			peer.notifyStatus(vec);
			return true;
		}
    		return false;
  	}
  

  	private void handle_dcs(String dcs) {
		System.out.println("DCS: "+dcs);
	}
  	private void handle_osc(String osc) {
		System.out.println("OSC: "+osc);
	}
  
	/**
	 * Put String at current cursor position. Moves cursor
	 * according to the String. Does NOT wrap.
	 * @param s the string
	 */
	public void putString(String s) {
		int	i,len=s.length();

		display.markLine(R,1);
		for (i=0;i<len;i++)
			putChar(s.charAt(i),false);
		display.putCursor(C, R);
		display.redraw();
		if(sb != null)
		  if(osn.equals("Windows 95"))
		    sb.setValues(display.getWindowBase(), 
				 display.getRows(), 
				 0, 
				 display.getBufferSize()); 
		  else
		    sb.setValues(display.getWindowBase(), 
				 display.getRows(), 
				 0, 
				 display.getBufferSize() - display.getRows());
	}

	public void putChar(char c) {
		putChar(c,true);
		display.redraw();
		if(sb != null)
		  if(osn.equals("Windows 95"))
		    sb.setValues(display.getWindowBase(), 
				 display.getRows(), 
				 0, 
				 display.getBufferSize()); 
		  else
		    sb.setValues(display.getWindowBase(), 
				 display.getRows(), 
				 0, 
				 display.getBufferSize() - display.getRows());
	}

	public void putChar(char c,boolean doshowcursor) {
		int	rows = display.getRows();
		int	columns = display.getColumns();
		int	tm = display.getTopMargin();
		int	bm = display.getBottomMargin();
		String	tosend;
		Vector	vec;
		byte	msg[];

		display.markLine(R,1);
		if (c>255) {
			if (debug>0)
				System.out.println("char > 255:"+(int)c);
			return;
		}
		switch (term_state) {
		case TSTATE_DATA:
			switch (c) {
			case OSC:
				osc="";
				term_state = TSTATE_OSC;
				break;
			case CSI:
				term_state = TSTATE_DCEQ;
				break;
			case IND:
				if (R==bm-1)
					display.insertLine(R,1,display.SCROLL_UP);
				else
					R++;
				if (debug>1)
					System.out.println("IND (at "+R+" )");
				break;
			case NEL:
				if (R==bm-1)
					display.insertLine(R,1,display.SCROLL_UP);
				else
					R++;
				C=0;
				if (debug>1)
					System.out.println("NEL (at "+R+" )");
				break;
			case HTS:
				Tabs[C] = 1;
				if (debug>1)
					System.out.println("HTS");
				break;
			case DCS:
				dcs="";
				term_state = TSTATE_DCS;
				break;
			case ESC:
				term_state = TSTATE_ESC;
				lastwaslf=0;
				break;
			case '\b':
				C--;
				if (C<0) 
					C=0;
				lastwaslf = 0;
				break;
			case '\t':
				if (insertmode == 1) {
					int	nr,newc;

					newc = C;
					do {
						display.insertChar(C,R,' ',attributes);
						newc++;
					} while (newc<columns && Tabs[newc]==0);
				} else {
					do {
						display.putChar(C++,R,' ',attributes);
					} while (C<columns && (Tabs[C]==0));
				}
				lastwaslf = 0;
				break;
			case '\r':
				C=0;
				break;
			case '\n':
				if (lastwaslf!=0 && lastwaslf!=c)
					break;
				lastwaslf=c;
				if (R == tm-1) {
					display.insertLine(R,1);
				} else { 
					if (R == bm) {
						display.insertLine(R,1);
					} else if (R == rows-1) {
						display.insertLine(R,1);
					} else {
						R++;
					}
				}
				/*C = 0;*/
				break;
			case '\016':
				/* ^N, Shift out - Put G1 into GL */
				gl = g1;
				break;

			case '\017':
				/* ^O, Shift in - Put G0 into GL */
				gl = g0;
				break;

			default:
				lastwaslf=0;
				if (c<32) {
					if (c!=0)
						if (debug>0)
							System.out.println("TSTATE_DATA char: "+((int)c));
					break;
				}
				if(C >= display.getColumns()) {
					if(R < rows - 1) 
						R++;
					else 	
						display.insertLine(R);
					C = 0;
				} 
				
				// Mapping if DEC Special is chosen charset
				if ( gl == '0' ) {
				    if ( c >= '\u005f' && c <= '\u007e' ) {
					if (debug>2)
					    System.out.print("Mapping "+c);
					c = DECSPECIAL[(short)c - 0x5f];
				    if (debug>2)
					System.out.println("to "+c);

				    }
				}
					                      
					
				if (insertmode==1) {
					display.insertChar(C, R, c, attributes);
				} else {
					display.putChar(C, R, c, attributes);
					C++;
				}
				break;
			}
			break;
		case TSTATE_OSC:
		  	if ((c<0x20) && (c!=ESC)) {//NP - No printing character
		  		handle_osc(osc);
			  	term_state = TSTATE_DATA;
				break;
			}
			//but check for vt102 ESC \
			if (c=='\\' && osc.charAt(osc.length()-1)==ESC) {
				handle_osc(osc);
				term_state = TSTATE_DATA;
				break;
			}
			osc = osc + c;
			break;
		case TSTATE_ESC:
			switch (c) {
			case '#':
				term_state = TSTATE_ESCSQUARE;
				break;
			case 'c':
				/* Hard terminal reset */
				/*FIXME:*/
				term_state = TSTATE_DATA;
				break;
			case '[':
				term_state = TSTATE_CSI;
				DCEvar		= 0;
				DCEvars[0]	= 0;
				DCEvars[1]	= 0;
				DCEvars[2]	= 0;
				DCEvars[3]	= 0;
				break;
			case ']':
				osc="";
				term_state = TSTATE_OSC;
				break;
			case 'P':
				dcs="";
				term_state = TSTATE_DCS;
				break;
			case 'E':
				if (R==bm-1)
					display.insertLine(R,1,display.SCROLL_UP);
				else
					R++;
				C=0;
				term_state = TSTATE_DATA;
				if (debug>1)
					System.out.println("ESC E (at "+R+" )");
				break;
			case 'D':
				System.out.println("ESC D (bm="+bm+",R="+R);
				if (R==bm)
					display.insertLine(R,1,display.SCROLL_UP);
				else
					R++;
				term_state = TSTATE_DATA;
				if (debug>1)
					System.out.println("ESC D (at "+R+" )");
				break;
			case 'M':
				if (R>tm)
					R--;
				else
					display.insertLine(R,1,display.SCROLL_DOWN);
				if (debug>1)
					System.out.println("ESC M");
				term_state = TSTATE_DATA;
				break;
			case 'H':
				if (debug>0)
					System.out.println("ESC H at "+C);
				/* right border probably ...*/
				if (C>=display.getColumns())
					C=display.getColumns()-1;
				Tabs[C] = 1;
				term_state = TSTATE_DATA;
				break;
			case '=':
				/*application keypad*/
				if (debug>0)
					System.out.println("ESC =");
				term_state = TSTATE_DATA;
				break;
			case '>':
				/*normal keypad*/
				if (debug>0)
					System.out.println("ESC >");
				term_state = TSTATE_DATA;
				break;
			case '7':
				/*save cursor */
				Sc = C;
				Sr = R;
				Sa = attributes;
				if (debug>1)
					System.out.println("ESC 7");
				term_state = TSTATE_DATA;
				break;
			case '8':
				/*restore cursor */
				C = Sc;
				R = Sr;
				attributes = Sa;
				term_state = TSTATE_DATA;
				if (debug>1)
					System.out.println("ESC 7");
				break;
			case '(':
				/* Designate G0 Character set (ISO 2022) */
				term_state = TSTATE_SETG0;
				if (debug>1)
					System.out.println("ESC (");
				break;
			case ')':
				/* Designate G0 character set (ISO 2022) */
				term_state = TSTATE_SETG1;
				if (debug>1)
					System.out.println("ESC )");
				break;
			case '*':
				/* Designate G1 Character set (ISO 2022) */
				term_state = TSTATE_SETG2;
				if (debug>1)
					System.out.println("ESC *");
				break;
			case '+':
				/* Designate G1 Character set (ISO 2022) */
				term_state = TSTATE_SETG3;
				if (debug>1)
					System.out.println("ESC +");
				break;
			default:
				if (debug>0)
					System.out.println("ESC unknown letter:"+c);
				term_state = TSTATE_DATA;
				break;
			}
			break;
		case TSTATE_SETG0:
			if(c=='0' || c=='A' || c=='B'){
			    g0 = c;
			}
			if (debug>1)
			    System.out.println("G0 char set? "+c);
			term_state = TSTATE_DATA;
			break;
		case TSTATE_SETG1:
			if(c=='0' || c=='A' || c=='B'){
			    g1 = c;
			}
			if (debug>1)
			    System.out.println("G1 char set? "+c);
			term_state = TSTATE_DATA;
			break;
		case TSTATE_SETG2:
			if(c=='0' || c=='A' || c=='B'){
			    g2 = c;
			}
			if (debug>1)
			    System.out.println("G2 char set? "+c);
			term_state = TSTATE_DATA;
			break;
		case TSTATE_SETG3:
			if(c=='0' || c=='A' || c=='B'){
			    g3 = c;
			}
			if (debug>1)
			    System.out.println("G3 char set? "+c);
			term_state = TSTATE_DATA;
			break;
		case TSTATE_ESCSQUARE:
			switch (c) {
			case '8':
				for (int i=0;i<columns;i++)
					for (int j=0;j<rows;j++)
						display.putChar(i,j,'E',0);
				break;
			}
			if (debug>1)
				System.out.println("ESC#8");
			term_state = TSTATE_DATA;
			break;
		case TSTATE_DCS:
			if (c=='\\' && dcs.charAt(dcs.length()-1)==ESC) {
				handle_dcs(dcs);
				term_state = TSTATE_DATA;
				break;
			}
			dcs = dcs + c;
			break;
		case TSTATE_DCEQ:
			switch (c) {
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				DCEvars[DCEvar]=DCEvars[DCEvar]*10+((int)c)-48;
				break;
			case 'r':
				if (debug>0)
					System.out.println("ESC [ ? "+DCEvars[0]+" r");
				/* DEC Mode reset */ 
				switch (DCEvars[0]){
				case 3: /* 132 columns*/
					break;
				case 4: /* scrolling mode, smooth */
					break;
				case 5: /* light background */
					break;
				case 6: /* move inside margins ? */
					break;
				case 12:/* local echo off */
					break;
				}
				term_state = TSTATE_DATA;
				break;
			case 'h':
				if (debug>0)
					System.out.println("ESC [ ? "+DCEvars[0]+" h");
				/* DEC Mode set */ 
				switch (DCEvars[0]){
				case 1:	/* Application cursor keys */
					KeyUp	= "OA";
					KeyDown	= "OB";
					KeyRight= "OC";
					KeyLeft	= "OD";
					break;
				case 3: /* 132 columns*/
					break;
				case 4: /* scrolling mode, smooth */
					break;
				case 5: /* light background */
					break;
				case 6: /* move inside margins ? */
					break;
				case 12:/* local echo off */
					break;
				}
				term_state = TSTATE_DATA;
				break;
			case 'l':
				/* DEC Mode reset */ 
				if (debug>0)
					System.out.println("ESC [ ? "+DCEvars[0]+" l");
				switch (DCEvars[0]){
				case 1:	/* Application cursor keys */
					KeyUp	= "[A";
					KeyDown	= "[B";
					KeyRight= "[C";
					KeyLeft	= "[D";
					break;
				case 3: /* 80 columns*/
					break;
				case 4: /* scrolling mode, jump */
					break;
				case 5: /* dark background */
					break;
				case 6: /* move outside margins ? */
					break;
				case 12:/* local echo on */
					break;
				}
				term_state = TSTATE_DATA;
				break;
			case ';':
				DCEvar++;
				DCEvars[DCEvar] = 0;
				break;
			case 'n':
				if (debug>0)
					System.out.println("ESC [ ? "+DCEvars[0]+" n");
				switch (DCEvars[0]) {
				case 15:
					/* printer? no printer. */
					tosend = ((char)ESC)+"[?13n";
					msg = new byte[tosend.length()];
					tosend.getBytes(0, tosend.length(), msg, 0);
					vec = new Vector(2);
					vec.addElement("SEND");
					vec.addElement(msg);
					peer.notifyStatus(vec);
					System.out.println("ESC[5n");
					break;
				default:break;
				}
				term_state = TSTATE_DATA;
				break;
			default:
				if (debug>0)
					System.out.println("ESC [ ? "+DCEvars[0]+" "+c);
				term_state = TSTATE_DATA;
				break;
			}
			break;
		case TSTATE_CSI:
			switch (c) {
			case '?':
				DCEvar=0;
				DCEvars[0]=0;
				term_state=TSTATE_DCEQ;
				if(debug>0)
				  System.out.println("->TSTATE_DCEQ");
				break;
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				DCEvars[DCEvar]=DCEvars[DCEvar]*10+((int)c)-48;
				break;
			case ';':
				DCEvar++;
				DCEvars[DCEvar] = 0;
				break;
			case 'c':/* send primary device attributes */
				/* send (ESC[?61c) */
				tosend = ((char)ESC)+"[?1;2c";
				vec = new Vector(2);
				msg = new byte[tosend.length()];
				tosend.getBytes(0, tosend.length(), msg, 0);
				vec.addElement("SEND");
				vec.addElement(msg);
				peer.notifyStatus(vec);
				term_state = TSTATE_DATA;
				if (debug>0)
					System.out.println("ESC [ "+DCEvars[0]+" c");
				break;
			case 'q':
				if (debug>0)
					System.out.println("ESC [ "+DCEvars[0]+" q");
				term_state = TSTATE_DATA;
				break;
			case 'g':
				/* used for tabsets */
				switch (DCEvars[0]){
				case 3:/* clear them */
					int nw = display.getColumns();
					Tabs = new byte[nw];
					break;
				default:
					Tabs[C] = 0;
					break;
				}
				if (debug>0)
					System.out.println("ESC [ "+DCEvars[0]+" g");
				term_state = TSTATE_DATA;
				break;
			case 'h':
				switch (DCEvars[0]) {
				case 4:
					insertmode = 1;
					break;
				}
				term_state = TSTATE_DATA;
				if (debug>0)
					System.out.println("ESC [ "+DCEvars[0]+" h");
				break;
			case 'l':
				switch (DCEvars[0]) {
				case 4:
					insertmode = 0;
					break;
				}
				term_state = TSTATE_DATA;
				if (debug>0)
					System.out.println("ESC [ "+DCEvars[0]+" l");
				break;
			case 'D':
				if (DCEvars[0]==0)
					C--;
				else
					C-=DCEvars[0];
				if (C<0) C=0;
				term_state = TSTATE_DATA;
				if (debug>1)
					System.out.println("ESC [ "+DCEvars[0]+" D");
				break;
			case 'C':
				if (DCEvars[0]==0)
					C++;
				else
					C+=DCEvars[0];
				if (C>columns-1)
					C=columns-1;
				term_state = TSTATE_DATA;
				if (debug>1)
					System.out.println("ESC [ "+DCEvars[0]+" C");
				break;
			case 'A':
				if (DCEvars[0]==0)
					R--;
				else
					R-=DCEvars[0];
				if (R<0) R=0;
				term_state = TSTATE_DATA;
				if (debug>1)
					System.out.println("ESC [ "+DCEvars[0]+" A");
				break;
			case 'r':
				if (DCEvar==0) {
					display.setTopMargin(0);
					display.setBottomMargin(rows);
				} else {
					display.setTopMargin(DCEvars[0]-1);
					display.setBottomMargin(DCEvars[1]-1);
				}
				if (debug>1)
					System.out.println("ESC ["+DCEvars[0]+" ; "+DCEvars[1]+" r");
				term_state = TSTATE_DATA;
				break;
			case 'H':	/* move cursor */
				/* gets 2 arguments */
				R = DCEvars[0]-1;
				C = DCEvars[1]-1;
				if (C<0) C=0;
				if (R<0) R=0;
				term_state = TSTATE_DATA;
				if (debug>2)
					System.out.println("ESC [ "+DCEvars[0]+";"+DCEvars[1]+" H");
				break;
			case 'f':	/* move cursor 2 */
				/* gets 2 arguments */
				R = DCEvars[0]-1;
				C = DCEvars[1]-1;
				if (C<0) C=0;
				if (R<0) R=0;
				term_state = TSTATE_DATA;
				if (debug>2)
					System.out.println("ESC [ "+DCEvars[0]+";"+DCEvars[1]+" f");
				break;
			case 'L':
				/* insert n lines */
				if (DCEvars[0]==0)
					display.insertLine(R);
				else 
					display.insertLine(R,DCEvars[0]);
				term_state = TSTATE_DATA;
				if (debug>1)
					System.out.println("ESC [ "+DCEvars[0]+" L");
				break;
			case 'B':
				/* cursor down n (1) times */
				if (DCEvars[0]==0)
					R++;
				else
					R+=DCEvars[0];
				while (R>rows-1) {
					display.insertLine(rows-1);
					R--;
				}
				term_state = TSTATE_DATA;
				if (debug>1)
					System.out.println("ESC [ "+DCEvars[0]+" B (at C="+C+")");
				break;
			case 'M':
				if (DCEvars[0]==0)
					display.deleteLine(R);
				else
					for (int i=1;i<DCEvars[0];i++)
						display.deleteLine(R);
				if (debug>1)
					System.out.println("ESC [ "+DCEvars[0]+"M");
				term_state = TSTATE_DATA;
				break;
			case 'K':
				if (debug>1)
					System.out.println("ESC [ "+DCEvars[0]+" K");
				/* clear in line */
				switch (DCEvars[0]) {
				case 0:/*clear to right*/
					if (C<columns-2)
						display.deleteArea(C,R,columns-C-1,1);
					break;
				case 1:/*clear to the left*/
					if (C>0)
						display.deleteArea(0,R,C-1,1);
					break;
				case 2:/*clear whole line */
					display.deleteArea(0,R,columns,1);
					break;
				}
				term_state = TSTATE_DATA;
				break;
			case 'J':
				/* clear display.below current line */
				switch (DCEvars[0]) {
				case 0:
					display.deleteArea(0,R,columns,rows-R);
					display.markLine(R,rows-R+1);
					break;
				case 1:
					display.deleteArea(0,0,columns,R-1);
					display.markLine(0,R);
					break;
				case 2:
					display.deleteArea(0,0,columns,rows);
					display.markLine(0,rows+1);
					break;
				}
				if (debug>1)
					System.out.println("ESC [ "+DCEvars[0]+" J");
				term_state = TSTATE_DATA;
				break;
			case 'n':
				switch (DCEvars[0]){
				case 5: /* malfunction? No malfunction. */
					tosend = ((char)ESC)+"[0n";
					vec = new Vector(2);
					msg = new byte[tosend.length()];
					tosend.getBytes(0, tosend.length(), msg, 0);
					vec.addElement("SEND");
					vec.addElement(msg);
					peer.notifyStatus(vec);
					System.out.println("ESC[5n");
					break;
				case 6:
					tosend = ((char)ESC)+"["+R+";"+C+"R";
					vec = new Vector(2);
					msg = new byte[tosend.length()];
					tosend.getBytes(0, tosend.length(), msg, 0);
					vec.addElement("SEND");
					vec.addElement(msg);
					peer.notifyStatus(vec);
					System.out.println("ESC[6n");
					break;
				default:
					if (debug>0)
						System.out.println("ESC [ "+DCEvars[0]+" n??");
					break;
				}
				term_state = TSTATE_DATA;
				break;
			case 'm':	/* attributes as color, bold , blink,*/
				if (debug>1)
					System.out.print("ESC [ ");
				if (DCEvar == 0 && DCEvars[0] == 0)
					attributes = 0;
				for (i=0;i<=DCEvar;i++) {
					switch (DCEvars[i]) {
					case 0:
						if (DCEvar>0)
							attributes =0;
						break;
					case 4:
						attributes |= CharDisplay.UNDERLINE;
						break;
					case 1:
						attributes |= CharDisplay.BOLD;
						break;
					case 7:
						attributes |= CharDisplay.INVERT;
						break;
					case 5: /* blink on */
						break;
					case 25: /* blinking off */
						break;
					case 27:
						attributes &= ~CharDisplay.INVERT;
						break;
					case 24:
						attributes &= ~CharDisplay.UNDERLINE;
						break;
					case 22:
						attributes &= ~CharDisplay.BOLD;
						break;
					case 30:
					case 31:
					case 32:
					case 33:
					case 34:
					case 35:
					case 36:
					case 37:
						attributes &= ~(0xf<<3);
						attributes |= ((DCEvars[i]-30)+1)<<3;
						break;
					case 40:
					case 41:
					case 42:
					case 43:
					case 44:
					case 45:
					case 46:
					case 47:
						attributes &= ~(0xf<<7);
						attributes |= ((DCEvars[i]-40)+1)<<7;
						break;

					default:
						
						break;
					}
					if (debug>1)
						System.out.print(""+DCEvars[i]+";");
				}
				if (debug>1)
					System.out.print(" (attributes = "+attributes+")m \n");
				term_state = TSTATE_DATA;
				break;
			default:
				if (debug>0)
					System.out.println("ESC [ unknwon letter:"+c);
				term_state = TSTATE_DATA;
				break;
			}
			break;
		default:
			term_state = TSTATE_DATA;
			break;
		}
		if (C >= columns) C = columns;
		if (R >= rows)	R = rows;
		if (C < 0)	C = 0;
		if (R < 0)	R = 0;
		if (doshowcursor) {
			display.putCursor(C, R);
		}
		display.markLine(R,1);
	}
}
