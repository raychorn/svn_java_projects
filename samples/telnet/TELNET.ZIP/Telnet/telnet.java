/**
 * telnet -- implements a simple telnet
 * --
 * $Id: telnet.java,v 1.28 1997/02/18 15:33:20 leo Exp $
 * $timestamp: Tue Feb 18 16:32:50 1997 by Matthias L. Jugel :$
 *
 * This file is part of "The Java Telnet Applet".
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * "The Java Telnet Applet" is distributed in the hope that it will be 
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

import java.applet.Applet;
import java.awt.Component;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Scrollbar;
import java.awt.Event;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.io.IOException;

import socket.TelnetIO;
import socket.StatusPeer;

import display.Terminal;

/**
 * A telnet implementation that supports different terminal emulations.
 * @version $Id: telnet.java,v 1.28 1997/02/18 15:33:20 leo Exp $
 * @author  Matthias L. Jugel, Marcus Mei�ner
 */
public class telnet extends Applet implements Runnable, StatusPeer
{
  /**
   * The telnet io methods.
   * @see socket.TelnetIO
   */
  protected TelnetIO tio;
  /**
   * The terminal emulation (dynamically loaded).
   * @see emulation
   */
  protected Terminal term;

  /**
   * The host address to connect to.
   */
  protected String address;
  /**
   * The port number (default ist 23).
   */
  protected int port;
  /**
   * Emulation type (default is vt320).
   */
  protected String emulation;

  private Panel p = new Panel();
  private Hashtable buttons = null;
  private Hashtable fields = null;

  private Hashtable script = null;

  private boolean localecho = true;
  private boolean connected = false;
  private int pressedKey = ' ';

  private Container parent = null;

  private Thread t;

  public Hashtable params;
    
  public String[][] getParameterInfo()
  {
    String pinfo[][];
    String info[][] = {
      {"address",  "String",   "IP address"},
      {"port",     "Integer",  "Port number"},
      {"emulation","String",   "Emulation to be used (standard is vt320)"},
    };
    String tinfo[][] = (term != null ? term.getParameterInfo() : null);
    if(tinfo != null) pinfo = new String[tinfo.length + 3][3];
    else pinfo = new String[3][3];
    System.arraycopy(info, 0, pinfo, 0, 3);
    System.arraycopy(tinfo, 0, pinfo, 3, tinfo.length);
    return pinfo;
  }

  public String getParameter(String name)
  {
    if(params == null) return super.getParameter(name);
    return (String)params.get(name);
  }

  /**
   * The main function is called on startup of the application.
   */
  public static void main(String args[]) 
  {
    telnet applet = new telnet();
    Frame frame = new Frame("telnet");

    frame.setLayout(new BorderLayout());
    frame.add("Center", applet);
    frame.resize(380, 590);

    // create params from command line arguments
    applet.params = new Hashtable();
    switch(args.length) 
    {
    case 2: applet.params.put("port", args[1]);
    case 1: applet.params.put("address", args[0]); 
      break;
    default: 
      System.out.println("Usage: java telnet host [port]");
      System.exit(0);
    } 
    applet.params.put("VTscrollbar", "true");
    applet.params.put("1#Button", "Exit|\\$exit()");
    applet.params.put("2#Button", "Connect|\\$connect(\\@address@,\\@port@)");
    applet.params.put("3#Input", "address#30|"
		      +(args.length > 0 ? args[0] : "localhost"));
    applet.params.put("4#Input", "port#4|23");
    applet.params.put("5#Button", "Disconnect|\\$disconnect()");

    applet.init();
    applet.start();

    frame.pack();
    frame.show();
  }
  
  /**
   * Initialize applet.
   */
  public void init()
  {
    String tmp; 

    if((address = getParameter("address")) == null)
      address = getDocumentBase().getHost();
    if((tmp = getParameter("port")) == null) 
      port = 23;
    else
      port = (new Integer(tmp)).intValue();
    
    if((emulation = getParameter("emulation")) == null)
      emulation = "vt320";

    try {
      term = (Terminal)Class.forName("display."+emulation).newInstance();
      term.InitializeTerminal(this);
      term.setPeer(this);
    } catch(Exception e) {
      e.printStackTrace();
    }

    int nr = 1;
    String button = null, input = null;
    while((button = getParameter(nr+"#Button")) != null ||
	  (input = getParameter(nr+"#Input")) != null)
    {
      nr++;
      if(button != null)
      {
	if(buttons == null) buttons = new Hashtable();
	int idx = button.indexOf('|');
	if(button.length() == 0)
	  System.out.println("ERROR: Button: no definition");
	if(idx < 0 || idx == 0)
	{
	  System.out.println("ERROR: Button: empty name \""+button+"\"");
	  continue;
	}
	if(idx == button.length() - 1)
	{
	  System.out.println("ERROR: Button: empty command \""+button+"\"");
	  continue;
	}
	Button b = new Button(button.substring(0, idx));
	buttons.put(b, button.substring(idx+1, button.length()));
	p.add(b);
      } else
      if(input != null)
      {
	if(fields == null) fields = new Hashtable();
	int idx = input.indexOf('|');
	if(input.length() == 0)
	System.out.println("ERROR: Input field: no definition");
	if(idx < 0 || idx == 0)
	{
	  System.out.println("ERROR: Input field: empty name \""+input+"\"");
	  continue;
	}
	int si, size;
	if((si = input.indexOf('#', 0)) == 0)
	{
	  System.out.println("ERROR: Input field: empty name");
	  continue;
	}
	if(si < 0 || si == idx-1) size = 10;
	else size = Integer.parseInt(input.substring(si+1, idx));
	TextField t = new TextField(input.substring(idx + 1, input.length()), size);
	fields.put(input.substring(0, (si < 0 ? idx : si)), t);
	p.add(t);
      }
      button = input = null;
    }
    
    setLayout(new BorderLayout());
    if(buttons != null || fields != null) add("North", p);
    add("Center", term);

    if((tmp = getParameter("script")) != null)
    {
      script = new Hashtable();
      int idx = tmp.indexOf('|');
      int oldidx = 0;
      while(idx >= 0) {
	String match = tmp.substring(oldidx, idx);
	oldidx = idx;
	idx = tmp.indexOf('|', idx+1);
	idx = idx < 0 ? idx = tmp.length() : idx;
	String send = tmp.substring(oldidx+1, idx);
	System.out.println("SCRIPT: MATCH("+match+") -> SEND("+send+")");
	script.put(match, send+"\r");
	oldidx = idx+1;
	idx = tmp.indexOf('|', idx+1);
      }
    }
  }

  public void start()
  {
    if(t == null)
      try {
	try {
	  tio = new TelnetIO();
	  tio.setPeer(this);
	  term.putString("Trying "+address+(port==23?"":" "+port)+" ...\n\r");
	  tio.connect(address, port);
	  term.putString("Connected to "+address+".\n\r");
	  connected = true;
	  localecho = true;
	} catch(IOException e) {
	  term.putString("Failed to connect.\n\r");
	  e.printStackTrace();
	}
        t = new Thread(this);
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
      } catch(Exception e) {
        e.printStackTrace();
      }
  }

  public void run()
  {
    while(t != null)
      try {
        String tmp = new String(tio.receive(), 0);
	if(script != null)
	{
	  Enumeration match = script.keys();
	  while(match.hasMoreElements())
	  {
	    String key = (String)match.nextElement();
	    if(tmp.indexOf(key) != -1)
	    {
	      int len = ((String)script.get(key)).length();
	      byte str[] = new byte[len];
	      ((String)script.get(key)).getBytes(0, len, str, 0);
	      tio.send(str);
	      script.remove(key);
	    }
	  }
	  if(script.isEmpty()) 
	  { 
	    script = null;
	    System.out.println("SCRIPT: DONE.");
	  }
	}
        term.putString(tmp);
      } catch(IOException e) {
	t.stop();
	try {
	  tio.disconnect();
	  term.putString("\n\rConnection closed.\n\r");
	  connected = false;
	} catch(IOException _e) {
	  _e.printStackTrace();
	}
      }
  }

  public boolean handleEvent(Event evt)
  {
    if(evt.id == Event.ACTION_EVENT && buttons.get(evt.target) != null)
    {
      String tmp = (String)buttons.get(evt.target);
      String cmd = "", function = null;
      int idx = 0, oldidx = 0;
      while((idx = tmp.indexOf('\\', oldidx)) >= 0 && ++idx <= tmp.length())
      {
	cmd += tmp.substring(oldidx, idx-1);
	switch(tmp.charAt(idx))
	{
	case 'n': cmd += "\n"; break;
	case 'r': cmd += "\r"; break;
	case '$':
	{
	  int ni = tmp.indexOf('(', idx+1);
	  if(ni < idx)
	  {
	    System.out.println("ERROR: Function: missing '('");
	    break;
	  }
	  if(ni == ++idx)
	  {
	    System.out.println("ERROR: Function: missing name");
	    break;
	  }
	  function = tmp.substring(idx, ni);
	  idx = ni+1;
	  ni = tmp.indexOf(')', idx);
	  if(ni < idx)
	  {
	    System.out.println("ERROR: Function: missing ')'");
	    break;
	  }
	  tmp = tmp.substring(idx, ni);
	  idx = oldidx = 0;
	  continue;
	}
	case '@': 
	{
	  int ni = tmp.indexOf('@', idx+1);
	  if(ni < idx) 
	  {
	    System.out.println("ERROR: Input Field: '@'-End Marker not found");
	    break;
	  }
	  if(ni == ++idx)
	  {
	    System.out.println("ERROR: Input Field: no name specified");
	    break;
	  }
	  String name = tmp.substring(idx, ni);
	  idx = ni;
	  TextField t;
	  if(fields == null || (t = (TextField)fields.get(name)) == null)
	  {
	    System.out.println("ERROR: Input Field: requested input \""
			      +name+"\" does not exist");
	    break;
	  }
	  cmd += t.getText();
	  break;
	}
	default : cmd += tmp.substring(idx, ++idx);
	}
	oldidx = ++idx;
      }

      if(oldidx <= tmp.length()) cmd += tmp.substring(oldidx, tmp.length());
      
      if(function != null)
      {
	if(function.equals("exit"))
	{ 
	  try {
	    System.exit(0);
	  } catch(Exception e) { e.printStackTrace(); }
	}
	if(function.equals("connect"))
	{
	  if(t != null) {
	    System.out.println("connect(): still connected!");
	    if(params == null) showStatus("Telnet: Still connected!");
	    return true;
	  }
	  try {
	    if(tio != null) tio.disconnect();
	    if((idx = cmd.indexOf(",")) >= 0) {
	      int tmpp;
	      try {
		tmpp = Integer.parseInt(cmd.substring(idx+1, cmd.length()));
	      } catch(Exception e) {
	        tmpp = port;
	      }
	      port = tmpp;
	      cmd = cmd.substring(0, idx);
	    }
	    if(cmd.length() > 0) address = cmd;
	    start();
	  } catch(Exception e) {
	    e.printStackTrace();
	  }
	} else
	if(function.equals("disconnect"))
	{
	  if(t != null) t.stop(); 
	  t = null;
	  try {
	    tio.disconnect();
	    term.putString("\r\nClosed connection.\r\n");
	  } catch(Exception e) {
	    e.printStackTrace();
	  }
	} else
	if(function.equals("detach"))
	  if(parent != null)
	  {
	    Frame top = (Frame)getParent();
	    System.out.println("telnet: reattaching...");
	    parent.setLayout(new BorderLayout());
	    parent.add("Center", this);
	    parent.validate();
	    parent.layout();
	    top.dispose();
	    parent = null;
	  }
	  else
	  {
	    System.out.println("telnet: detaching...");
	    parent = getParent();
	    Frame top = new Frame("The Java Telnet Applet ["+
				  address+(port==23?"":" "+port)+"]");
	    Dimension s = size();
	    top.reshape(0, 0, s.width, s.height);
	    top.setLayout(new BorderLayout());
	    top.add("Center", this);
	    top.pack();
	    top.show();
	  }
	else
	System.out.println("ERROR: function not implemented: \""
                             +function+"\"");
	return true;
      }
      cmd += tmp.substring(oldidx, tmp.length());
      byte[] buf = new byte[cmd.length()];
      cmd.getBytes(0, cmd.length(), buf, 0);
      try {
	if(connected) tio.send(buf);
	else localecho = true;
	if (localecho) term.putString(new String(buf, 0));
      } catch(IOException e) {
	try {
	  tio.disconnect();
	  term.putString("\n\rConnection closed.\n\r");
	  connected = false;
	} catch(IOException _e) {
	  _e.printStackTrace();
	}
      }
      return true;
    }
      
    if(fields != null)
      for(Enumeration e = fields.elements(); e.hasMoreElements();) 
	if(e.nextElement() == evt.target) return false;

    if(evt.id == Event.MOUSE_DOWN) ((Component)evt.target).requestFocus();

    /* Netscape for windows does not send keyDown when period is pressed.
     * This hack catches the keyUp event.
     */
    int id = evt.id;
    if(evt.key == '.' && evt.id == Event.KEY_RELEASE && evt.key != pressedKey)
      evt.id = Event.KEY_PRESS;
    
    if(evt.id == Event.KEY_PRESS)
    {
      if(id == Event.KEY_PRESS) pressedKey = evt.key;
      try {
        if(connected) {
		if (evt.key == 10) {
			tio.send((byte)13);
			tio.send((byte)0);/* YES, see RFC 854 */
		} else if ((evt.key == '2' ||
			    evt.key == '@' ||
			    evt.key == ' ') &&
			   evt.controlDown()) {
         		tio.send((byte)0);
		} else {
			tio.send((byte)evt.key);
		}
	}
	else localecho = true;
	if (localecho) {
	  if (evt.key!=10)
	    term.putChar((char)evt.key);
	  else {
	    term.putChar((char)13);
	    term.putChar((char)10);
	  }
	}
      } catch(IOException e) {
	try {
	  tio.disconnect();
	  term.putString("Connection closed.\n\r");
	  connected = false;
	} catch(IOException _e) {
	  _e.printStackTrace();
	}
      }
      return true;
    }
    return false;
   }

  public Object notifyStatus(Vector status)
  {
    String what = (String)status.elementAt(0);
    if(what.equals("NAWS"))
      return term.getSize();
    if(what.equals("TTYPE"))
      if(term.getTerminalType() == null)
	return emulation;
      else return term.getTerminalType();
    if(what.equals("LOCALECHO"))
      localecho = true;
    if(what.equals("NOLOCALECHO")) 
      localecho = false;
    if(what.equals("SEND"))
       try {
	 tio.send((byte[])status.elementAt(1));
       } catch(IOException e) { e.printStackTrace(); }
    return null;
  }
}
